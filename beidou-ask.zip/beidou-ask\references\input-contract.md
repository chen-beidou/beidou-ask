# Input contract

Normalize the request into this internal record without displaying it unless the user asks:

```text
target_model
duration_per_clip
aspect_ratio: 16:9 | 9:16
medium
scene_mode: dialogue | action | mixed | one_take
total_story_duration
characters_and_relationships
scene_objective
primary_opposition
required_end_state
assets
dialogue
sound_and_music
content_constraints
delivery_format
```

## Priority

0. User-stored preference (project memory / CLAUDE.md): default 画幅, 时长, 风格, 节奏, 语言.
1. Explicit current-turn choices.
2. Supplied assets and established project continuity.
3. Existing script facts.
4. Conservative defaults from `SKILL.md`.

Never override a named model, duration, aspect ratio, line of dialogue, character identity, or required outcome merely to simplify generation.

Treat supplied dialogue as immutable source text. Record authorized dialogue rewriting explicitly; absence of authorization means verbatim preservation.

## Asset anchors

Default assumption: **every named asset has a reference image**. Anchor with the bare `@Name` the first time it appears in each independently generated Clip; later mentions use only the name. Never write appearance descriptions for named assets — the reference image owns appearance, and the prompt carries only action, expression, posture, and state.

Only when the user explicitly says an asset has no reference image may the anchor carry at most two inferred traits, and the asset card says `外观为推断`.

Do not create image-generation prompts, fake uploaded assets, or invented formal state-asset names.

## When one question is necessary

Ask only if at least one of these is unknowable and alternatives would create different stories:

- Who the central character is.
- What relationship drives the scene.
- Whether a critical action succeeds.
- Which mutually exclusive ending is required.

Otherwise proceed with defaults and state material assumptions in `生成前提醒`.
